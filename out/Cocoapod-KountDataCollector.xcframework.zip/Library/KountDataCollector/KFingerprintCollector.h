//
//  KFingerprintCollector.h
//  KountDataCollector
//
//  Created by Keith Feldman on 1/13/16.
//  Copyright © 2016 Kount Inc. All rights reserved.
//

#import "KCollectorTaskBase.h"

@interface KFingerprintCollector : KCollectorTaskBase

@end
