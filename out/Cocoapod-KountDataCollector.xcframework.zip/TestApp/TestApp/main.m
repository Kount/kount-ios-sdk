//
//  main.m
//  TestApp
//
//  Created by Keith Feldman on 1/28/16.
//  CCopyright © 2016 Kount Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
  }
}
