//
//  AppDelegate.h
//  TestApp
//
//  Created by Keith Feldman on 1/28/16.
//  CCopyright © 2016 Kount Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

