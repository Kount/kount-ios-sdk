//
//  LogsCell.swift
//  SampleAppSwift
//
//  Created by Felipe Plaza on 13-11-23.
//

import UIKit

class LogsCell: UITableViewCell {
    //MARK: Oulets
    @IBOutlet weak var logLabel: UILabel!
}
