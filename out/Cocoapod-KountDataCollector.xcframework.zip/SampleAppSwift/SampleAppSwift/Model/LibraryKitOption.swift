//
//  LibraryKitOption.swift
//  SampleAppSwift
//
//  Created by Alejandro Villalobos on 26-08-24.
//

struct LibraryKitOption {
    let title: String
    let imageName: String
    let isEnabled: Bool
}
