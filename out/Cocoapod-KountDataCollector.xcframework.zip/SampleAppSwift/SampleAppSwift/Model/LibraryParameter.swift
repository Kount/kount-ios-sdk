//
//  LibraryParameter.swift
//  SampleAppSwift
//
//  Created by Alejandro Villalobos on 19-08-24.
//

struct LibraryParameter {
    let name: String
    let requiresLiveUpdates: Bool
    var value: String
}
