//
//  LibraryCategory.swift
//  SampleAppSwift
//
//  Created by Alejandro Villalobos on 26-08-24.
//

enum LibraryCategory {
    case coreMotion
    case darwin
    case system
    case uiKit
}
